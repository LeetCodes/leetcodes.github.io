from ConfigParser import ConfigParser
from urllib import quote_plus, unquote_plus, urlencode

import collections
import HTPCSolutions
import operator
import subprocess
import sys
import xbmc, xbmcaddon

####################################################################################################

addon = xbmcaddon.Addon()
config = ConfigParser()
db = HTPCSolutions.DB()
http = HTPCSolutions.HTTP()
parameters = HTPCSolutions.Parameters()
settings = HTPCSolutions.Settings()
ui = HTPCSolutions.UI()

####################################################################################################

class Auth(HTPCSolutions.Auth):

	def validate(self):
		
		if self.hasCredentials == True:
				
			http.url("https://skyid.sky.com/signin/skygo", {
				'username': self.username,
				'password': self.password
			})

			if http.cookies.get('skySSO') is not None:
				self.authenticated = True
				return True
			else:
				self.authenticated = False
				return False

		return False

####################################################################################################

class Main(HTPCSolutions.Debug):

	def __init__(self):

		self.auth = Auth()

		if self.auth.hasCredentials == False:
			ui.dialog("Credentials", "Please enter your SkyGo username and password before continuing.")
			settings.open()

		self.auth.validate()	
		
		if parameters.count() < 1:
			self.debug("action is default")
			self.list()
		
		elif parameters.has("mode") and parameters.has("action"):	

			mode = parameters.get("mode")
			action = parameters.get("action")
			
			self.debug( "mode {0} - action {1}".format(mode, action) )

			if mode == "client" and action == "launch":
				Client().launch()
			elif mode == "live" and action == "channels":
				Live().channels()
			elif mode == "live" and action == "integrate":
				Live().integrate()
			elif mode == "live" and action == "update":
				Live().update()
			elif mode == "settings" and action == "clear":
				settings.clear()
			elif mode == "settings" and action == "open":
				settings.open()
			else:
				self.debug("Nice try, I don't support this mode/action")

		else:
			
			self.ui.end(False)


	def list(self):
		ui.add("Live TV", "live", "channels", image=None, isFolder=True)
		ui.add("Settings", "settings", "open", image=None, isFolder=False)
		ui.end()

####################################################################################################

class Client(HTPCSolutions.Debug):

	def __init__(self):
		super(Client, self).__init__()
		
		self.auth = Auth()
		self.executable = xbmc.translatePath(addon.getAddonInfo('path') + "/resources/bin/client.exe").decode('utf-8')
		self.process = None

	def launch(self, mode = "live", **kwargs):

		http.cookies.set(name="cookieBannerDismissed", value="true", domain=".sky.com")
		
		cookies = {}
		for cookie in http.cookies._jar:
			cookies[cookie.name] = cookie.value

		arguments = [
			self.executable,
			"--channel-id", str(parameters.get('id')),
			"--channel-name", parameters.get('name'),
			"--channel-number", str(parameters.get('id')),
			"--channel-sleep", settings.get('channel.sleep'),
			"--cookies", urlencode(cookies),
			"--debug-enabled", settings.get('debug.enabled'),
			"--fullscreen-offset-x", settings.get('fullscreen.offset.x'),
			"--fullscreen-offset-y", settings.get('fullscreen.offset.y'),
			"--mode", mode
		]

		self.debug(arguments)

		self._process = subprocess.Popen(arguments, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
	
####################################################################################################

class Live(HTPCSolutions.Debug):

	tvguide = xbmc.translatePath("special://home/addons/script.tvguide/resources/addons.ini")
	url = "http://epgservices.sky.com/4.3.0/api/2.0//region/json/4110/101"

	def __init__(self):

		super(Live, self).__init__()

		self.table = db.table('channels')

	def channels(self):
		
		# for i in sorted(self.configuration._json, key=operator.itemgetter(0)):
		for channel in self.table.all():
			ui.add(channel["name"], "client", "launch", image=channel["thumb"], isFolder=False, params = dict(channel) )
		ui.end()

	def integrate(self):

		self.debug("Integrating with TVGuide Addon")
		
		config.read(Live.tvguide)

		if config.has_section(addon.getAddonInfo('id')):
			config.remove_section(addon.getAddonInfo('id'))

		config.add_section(addon.getAddonInfo('id'))

		for channel in self.table.all():
			config.set(addon.getAddonInfo('id'), channel['name'], "plugin://{0}/?mode=client&action=launch&id={1}&name={2}".format( addon.getAddonInfo('id'), channel['id'], quote_plus(channel['name']) ) )

		with open(xbmc.translatePath('special://home/addons/script.tvguide/resources/addons.ini'), 'wb') as configfile:
			config.write(configfile)


	def update(self):

		self.notify("Update Starting")
		
		# Get List Of Channels
		data = http.json(Live.url)

		# check to ensure data was returned
		if not data:
			self.debug("No data was return from the server", xbmc.LOGERROR)
			return False

		# Check to see if we've received anything.
		if ((data == "") or (data.has_key('init') == False)):
			debug("%s - JSON is invalid" % (__name__))
			return False
		
		# Remove all exisiting records
		self.table.remove()

		# Enumerate JSON Category
		for item in data['init']['channels']:
			self.table.insert({
				'genre': item['c'][3],
				'id': item['c'][0],
				'number': item['c'][1],
				'name': item['t'],
				'thumb': ('http://epgstatic.sky.com/epgdata/1.0/newchanlogos/500/500/skychb%s.png' % item['c'][0]),
				'type': item['pt']
			})

		self.notify("Update Completed")

####################################################################################################

if __name__ == "__main__":
	Main()
