

import dns.resolver
import json
import os
import socket
import urllib, urllib2

####################################################################################################

# set global timeout - useful for slow connections.
socket.setdefaulttimeout(30)

####################################################################################################


class Debug():
	pass

class Error():
	pass


class DNS(Debug):

	def lookup(self, hostname, options={}):
		pass
	
	def _resolve(self, **kwargs):

		hostname = kwargs.get('hostname', None)
		rrtype = kwargs.get('rrtype', 'A')

		if hostname is None:
			return self._error("@hostname must be specified")
		elif rrtype not in ['A','CNAME','MX','NS','SOA','SRV','TXT']:
			return self._error("@rrtype specified invalid")

		answers = dns.resolver.query(hostname, rrtype)

		for rdata in answers:
			print 'Host', rdata.exchange, 'has preference', rdata.preference


	def resolve4(self, hostname):
		return resolve(hostname, type='IPV4')

	def resolve6(self, hostname):
		return resolve(hostname, type='IPV6')

	def resolveCName(self, hostname):
		return resolve(hostname, type='CNAME')

	def resolveMX(self, hostname):
		return resolve(hostname, type='MX')

	def resolveNs(self, hostname):
		return resolve(hostname, type='NS')

	def resolveSoa(self, hostname):
		return resolve(hostname, type='SOA')

	def resolveSrv(self, hostname):
		return resolve(hostname, type='SRV')

	def resolveTxt(self, hostname):
		return resolve(hostname, type='TXT')

	def reverse(self, ip):
		return resolve(ip)

class Net(Debug):
	pass

class HTTP(Debug):
	pass

class SMTP(Debug):
	pass
