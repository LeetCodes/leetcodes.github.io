from debug import Debug

import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

class Window(Debug, xbmcgui.WindowXMLDialog):

	def clearProperty(self, name, value, **kwargs):
		xbmcgui.Window(self.id).clearProperty(name)

	def setProperty(self, name, value, **kwargs):
		xbmcgui.Window(self.id).setProperty(name, value)

	def onAction(self):
		pass

	def onClick(self):
		pass

	def onFocus(self):
		pass

	def onInit(self):
		self.id = xbmcgui.getCurrentWindowDialogId()





