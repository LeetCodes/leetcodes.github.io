
from debug import Debug

import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

class Settings(Debug):

	def clear(self):
		pass

	def get(self, name = None):
		return addon.getSetting(name)

	def open(self):
		addon.openSettings()

	def set(self, name = None, value = None):
		addon.setSetting(name, value)

####################################################################################################