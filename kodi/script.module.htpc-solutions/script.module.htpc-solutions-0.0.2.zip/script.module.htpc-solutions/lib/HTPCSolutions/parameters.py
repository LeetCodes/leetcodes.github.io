

from debug import Debug
from urllib import quote_plus, unquote_plus
from urlparse import parse_qs

import sys
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

class Parameters(Debug):

	def __init__(self):
		super(Parameters, self).__init__()

		self._parameters = {}

		try:
			params = sys.argv[2]
		except:
			params = {}

		if type(params) is dict:
			self._parameters = params
		elif type(params) is str:
			self.parse(params)
		else:
			self.debug("Unsupported type [data]")
	
	def add(self, name=None, value=None, overwrite=False):
		
		if name == None:
			self.debug("Parameter [name] not specified", xbmc.LOGERROR)
			return False

		if (name is not self._parameters.keys()) or (overwrite == True):
			
			self._parameters[name] = value
			self.debug("Parameter %s set to %s" % (name, value), xbmc.LOGNOTICE)
			return True
		
		else:
			
			self.debug("Parameter %s already exists" % (name), xbmc.LOGERROR)
			return False

	def compose(self, data=None, seperator="&"):
		
		params = ""

		if data == None:
			data = self._parameters
		
		if not (type(data) is dict):
			self.debug("Parameter [data] must be a dictionary object", xbmc.LOGERROR)
			return params
		
		try:
			sep = "?"
			# enumerate keys in data
			for k in data:
				# add value to end of existing value
				params += sep + quote_plus(k) + '=' + quote_plus( str( data[k] ) )
				sep = seperator
		except:
			self.debug("Exception Error")
			params = None

		return params

	def count(self):
		return len(self._parameters)

	def get(self, name=None, default=None):

		if name == None:
			self.debug("Parameter [name] not specified", xbmc.LOGERROR)
			return default

		# check to ensure name actually exists
		if (not name in self._parameters.keys()):
			self.debug("Parameter %s does not exists" % (name), xbmc.LOGNOTICE)
			return default

		return self._parameters[name]

	def has(self, name=None):
		if not name:
			self.debug("Parameter [name] not specified", xbmc.LOGERROR)
			return False
		return (name in self._parameters.keys())

	def parse(self, data=None, overwrite=False):
		
		if data == None:
			self.debug("Parameter [data] not specified", xbmc.LOGERROR)
			return False

		if len(data) > 1:
			
			# replace unwanted data
			data = data.replace('?','')
			params = parse_qs(data)
			
			# enumerate parameters
			for p in params:
				try:
					v = params[p][0]
				except:
					v = ""
				
				# store value
				self.add(p, v, overwrite)

	def remove(self, name):
		
		# check to ensure name actually exists
		if (not name in self._parameters.keys()):
			self.debug("Parameter %s does not exists" % (name), xbmc.LOGNOTICE)
			return True

		# delete the key
		del self._parameters[name]
		return True

	def update(self, name=None, value=None):
		self.add(name, value, True)

####################################################################################################