
import inspect
import xbmc, xbmcaddon, xbmcgui, xbmcplugin

####################################################################################################

addon = xbmcaddon.Addon()

####################################################################################################

class Debug(object):

	addon = xbmcaddon.Addon()

	def debug(self, message, level=xbmc.LOGNOTICE):
		if addon.getSetting('debug.enabled') == "true":
			xbmc.log("[%s] %s.%s() - %s" % (addon.getAddonInfo('id'), type(self).__name__, inspect.stack()[1][3], message), level)

	def notify(self, message, time=3000, image=None):
		if image == None:
			pass
			# image = media["icon"]
		xbmc.executebuiltin("Notification(%s, %s - %s, %s, %s)" % (addon.getAddonInfo('name'), type(self).__name__, message, time, image))
