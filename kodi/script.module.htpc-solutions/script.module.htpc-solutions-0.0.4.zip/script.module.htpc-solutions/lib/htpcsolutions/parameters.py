from urllib import quote_plus, unquote_plus
from urlparse import parse_qs

import htpcsolutions.debug as debug
import sys

####################################################################################################

_parameters = {}

####################################################################################################

def add(name=None, value=None, overwrite=False):
	
	if name == None:
		debug.error("Parameter [name] not specified")
		return False

	if (name is not _parameters.keys()) or (overwrite == True):
		_parameters[name] = value
		return True
	else:
		return False

def compose(data=None, seperator="&"):
	
	params = ""

	if data == None:
		data = _parameters
	
	if not (type(data) is dict):
		debug.error("Parameter [data] must be a dictionary object")
		return params
	
	try:
		sep = "?"
		# enumerate keys in data
		for k in data:
			# add value to end of existing value
			params += sep + quote_plus(k) + '=' + quote_plus( str( data[k] ) )
			sep = seperator
	except:
		debug.error("Exception Error")
		params = None

	return params

def count():
	return len(_parameters)

def get(name=None, default=None):

	if name == None:
		debug.error("Parameter [name] not specified")
		return default

	# check to ensure name actually exists
	if (not name in _parameters.keys()):
		debug.notice( "Parameter %s does not exists" % (name) )
		return default

	return _parameters[name]

def has(name=None):
	if not name:
		debug.error("Parameter [name] not specified")
		return False
	return (name in _parameters.keys())

def parse(data=None, overwrite=False):
	
	if data == None:
		debug.error("Parameter [data] not specified")
		return False

	if len(data) > 1:
		
		# replace unwanted data
		data = data.replace('?','')
		params = parse_qs(data)
		
		# enumerate parameters
		for p in params:
			try:
				v = params[p][0]
			except:
				v = ""
			
			# store value
			add(p, v, overwrite)

def remove(name):
	if (not name in _parameters.keys()):
		debug.notice("Parameter %s does not exists" % (name))
		return True
	del _parameters[name]
	return True

def update(name=None, value=None):
	add(name, value, True)

####################################################################################################

try:
	params = sys.argv[2]
except:
	params = {}

if type(params) is dict:
	_parameters = params
elif type(params) is str:
	parse(params)
else:
	debug.error("Unsupported type [data]")

####################################################################################################