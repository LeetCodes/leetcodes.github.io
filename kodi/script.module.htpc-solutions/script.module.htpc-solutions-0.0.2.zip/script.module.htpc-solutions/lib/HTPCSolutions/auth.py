
from db import DB
from debug import Debug
from http import HTTP
from settings import Settings

import xbmc, xbmcaddon, xbmcgui, xbmcplugin


####################################################################################################


class Auth(Debug):

	def __init__(self):
		self.authenticated = False
		self.settings = Settings()
		self.http = HTTP()
		self.table = DB().table('auth')

	@property
	def hasCredentials(self):
		
		if (self.settings.get('credentials.username') == "" or self.settings.get('credentials.password') == ""):
			return False
		else:
			return True

	@hasCredentials.setter
	def hasCredentials(self):
		
		self.username = ""
		self.password = ""

	@property
	def password(self):
		return self.settings.get('credentials.password')

	@password.setter
	def password(self, value):
		self.settings.set('credentials.password', value)

	@property
	def username(self):
		return self.settings.get('credentials.username')

	@username.setter
	def username(self, value):
		self.settings.set('credentials.username', value)

	def validate(self):
		pass