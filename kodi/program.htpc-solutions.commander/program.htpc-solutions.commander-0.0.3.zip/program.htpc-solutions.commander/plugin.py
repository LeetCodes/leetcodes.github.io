from ConfigParser import ConfigParser

import collections
import HTPCSolutions
import json
import operator
import os
import subprocess
import sys
import xbmc, xbmcaddon

####################################################################################################

addon = xbmcaddon.Addon()
config = ConfigParser()

db_file = xbmc.translatePath("special://addons/%s/db.json" % ( xbmcaddon.Addon().getAddonInfo('id') ) )
db = HTPCSolutions.DB()
parameters = HTPCSolutions.Parameters()
ui = HTPCSolutions.UI()
where = HTPCSolutions.where

####################################################################################################

class Main(HTPCSolutions.Debug):

	def __init__(self):

		self._commands = db.table('commands')
		self._categories = db.table('categories')

		if parameters.count() < 1:
			self.debug("action is default")
			self.categories()
			
		elif parameters.has("mode") and parameters.has("action"):	

			mode = parameters.get("mode")
			action = parameters.get("action")

			if mode == "command" and action == "list":
				self.list()
			elif mode == "command" and action == 'run':
				self.run()

		else:
			ui.end(False)

	def categories(self, name=None, value=None):

		for cat in self._categories.all():
			ui.add(cat["name"], "command", "list", image=None, isFolder=True, params = { 'category': cat["id"] }) 
		ui.end()

	def list(self):

		if parameters.has("category"):
			commands = self._commands.search(where('category') == parameters.get("category"))
		else:
			commands = self._commands.all()

		for cmd in commands:
			ui.add(cmd["name"], "command", "run", image=None, isFolder=False, params = dict(cmd) )
		ui.end()

	def run(self):

		if not os.path.isfile(parameters.get("executable")):
			self.notify("Executable file not found")
			return

		arguments = [
			parameters.get("executable")
		]

		if parameters.has('parameters') and parameters.get('parameters') != None:
			arguments.extend([parameters.get('parameters')])

		self.debug(arguments)

		self._process = subprocess.call(arguments, shell=False)

####################################################################################################

if __name__ == "__main__":
	Main()
